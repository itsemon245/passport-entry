<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/print.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('actions'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex gap-2 2xl:gap-8 justify-center items-center mb-2 lg:-mt-12 !print:hidden">
        <form x-ref="form" class="flex max-sm:flex-col max-md:flex-wrap  gap-2 2xl:gap-8 justify-center items-center !print:hidden"
            action="<?php echo e(route('report.index')); ?>" method="get" x-data="{dateFrom: '<?php echo e(today('Asia/Dhaka')->subDays(today()->day - 1)->format('Y-m-d')); ?>', dateTo: '<?php echo e(today('Asia/Dhaka')->format('Y-m-d')); ?>'}">

            <div class="print:hidden">
                <label for="date_from" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date
                    From</label>
                <div class="relative flex items-center">
                    <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                        </svg>
                    </div>
                    <input @change="dateFrom = $el.value; $refs.print.href = `/dashboard/report/print?date_from=${dateFrom}&date_to=${dateTo}`" id="date_from" name="date_from" type="date"
                        value="<?php echo e(request()->query('date_from') ?? today('Asia/Dhaka')->subDays(today()->day - 1)->format('Y-m-d')); ?>"
                        class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Select date From">
                </div>
            </div>
            <div>
                <label for="date_to" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date
                    To</label>
                <div class="relative flex items-center">
                    <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                        </svg>
                    </div>
                    <input id="date_to" name="date_to" type="date"
                        value="<?php echo e(request()->query('date_to') ?? today('Asia/Dhaka')->format('Y-m-d')); ?>"
                        class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Select date To">
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $attributes; } ?>
<?php $component = App\View\Components\BtnPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnPrimary::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'md:mt-7']); ?>Refresh <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $attributes = $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $component = $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
        </form>

        
        <a x-ref="print" href="<?php echo e(route('report.print')."?date_from=".today('Asia/Dhaka')->subDays(today('Asia/Dhaka')->day-1)->format('Y-m-d')."&date_to=".today('Asia/Dhaka')->format('Y-m-d')); ?>" role="button" class="flex gap-2 items-center justify-between w-max px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-blue-600 border border-transparent rounded-lg active:bg-blue-600 hover:bg-blue-700 focus:outline-none focus:shadow-outline-blue max-md:mb-5 md:mt-7 md:block">Print</a>
    </div>
    <div class="w-full overflow-hidden rounded-lg shadow-xs">
        <div class="w-full overflow-x-auto">
            <table class="w-full whitespace-no-wrap print:w-screen" id="printable">
                <thead>
                    <tr
                        class="text-xs font-semibold tracking-wide text-left text-gray-700 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                        <th rowspan="2" class="px-4 text-center border py-1 print:px-2">No.</th>
                        <th rowspan="2" class="px-4 text-center border py-1 print:px-2">Client Name</th>
                        <th colspan="2" class="px-4 text-center border py-1 print:px-2">Survey</th>
                        <th rowspan="2" class="px-4 text-center border py-1 print:px-2">Application ID</th>
                        <th rowspan="2" class="px-4 text-center border py-1 print:px-2">Police Station</th>
                    </tr>
                    <tr
                        class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                        <th class="px-4 text-center border py-1 print:px-2">Channel</th>
                        <th class="px-4 text-center border py-1 print:px-2">General</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-gray-700 dark:text-gray-400">
                            <td class="align-middle text-center border"><?php echo e(++$key); ?></td>
                            <td class="px-4 py-1 print:px-2 border">
                                <div class="flex items-center text-sm">
                                    <!-- Avatar with inset shadow -->
                                    <div class="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                                        <img class="object-cover w-full h-full rounded-full" src="<?php echo e($client->avatar); ?>"
                                            alt="" loading="lazy" />
                                        <div class="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
                                    </div>
                                    <div>
                                        <p class="font-semibold"><?php echo e($client->name); ?></p>
                                        <p class="text-xs text-gray-600 dark:text-gray-400">
                                            <?php echo e($client->username); ?>

                                        </p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-1 print:px-2 text-sm capitalize border text-center">
                                <?php echo e($client->channel_count); ?>

                            </td>
                            <td class="px-4 py-1 print:px-2 text-sm capitalize border text-center">
                                <?php echo e($client->general_count); ?>

                            </td>
                            <td class="text-sm  border">
                                <?php $__currentLoopData = $client->entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table
                                        class="<?php echo e($client->entries->count() == 1 || $i == 0 ? '' : 'border-t'); ?> w-full">
                                        <tr>
                                            <td class="text-center px-4 py-1 print:px-2"><?php echo e($entry->application_id); ?></td>
                                        </tr>
                                    </table>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="text-sm border">
                                <?php $__currentLoopData = $client->entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table
                                        class="<?php echo e($client->entries->count() == 1 || $i == 0 ? '' : 'border-t'); ?> w-full">
                                        <tr>
                                            <td class="text-center px-4 py-1 print:px-2"><?php echo e($entry->police_station); ?></td>
                                        </tr>
                                    </table>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal1411ee955ee315282daf3f10c0873057 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1411ee955ee315282daf3f10c0873057 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tr.no-records','data' => ['colspan' => '7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tr.no-records'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => '7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1411ee955ee315282daf3f10c0873057)): ?>
<?php $attributes = $__attributesOriginal1411ee955ee315282daf3f10c0873057; ?>
<?php unset($__attributesOriginal1411ee955ee315282daf3f10c0873057); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1411ee955ee315282daf3f10c0873057)): ?>
<?php $component = $__componentOriginal1411ee955ee315282daf3f10c0873057; ?>
<?php unset($__componentOriginal1411ee955ee315282daf3f10c0873057); ?>
<?php endif; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>





        
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/print.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Report'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emon/projects/passport-entry/resources/views/dashboard/report/index.blade.php ENDPATH**/ ?>