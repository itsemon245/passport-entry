<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/tail-select.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/tail.select.js@1.0.0/js/tail.select.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            tail.select('.tail-select')

            document.addEventListener('htmx:afterSettle', () => {
                tail.select('.tail-select').reload()
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('actions'); ?>
    <?php if (isset($component)) { $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $attributes; } ?>
<?php $component = App\View\Components\BtnPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnPrimary::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-modal-target' => 'create-modal','data-modal-toggle' => 'create-modal']); ?>
        <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
        New Entry
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $attributes = $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $component = $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
    <!-- Main modal -->
    <div id="create-modal" tabindex="-1" aria-hidden="true"
        class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        New Entry
                    </h3>
                    <button type="button"
                        class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        data-modal-hide="create-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                            viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <form hx-post="<?php echo e(route('entry.store')); ?>" hx-select="#hx-create-form"
                    hx-target="#hx-create-form" hx-swap="outerHTML" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="p-4 md:p-5 space-y-4">

                        <div id="hx-create-form" class="grid gap-6 mb-6 md:grid-cols-2" x-data="{ isChannel: true }">

                            <div role="button" :class="{ 'bg-purple-600': isChannel }"
                                class="flex max-w-max items-center px-4 border border-gray-200 rounded-lg dark:border-gray-700">
                                <input @change="isChannel= true" id="bordered-radio-1" type="radio" value="true"
                                    name="is_channel" checked
                                    class="hidden w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                <label for="bordered-radio-1"
                                    :class="{ 'text-gray-100': isChannel, 'text-gray-900': !isChannel }"
                                    class="w-full py-2 text-sm font-medium dark:text-gray-300">Channel</label>
                            </div>
                            <div role="button" :class="{ 'bg-purple-600': !isChannel }"
                                class="flex justify-self-end max-w-max items-center px-4 border border-gray-200 rounded-lg dark:border-gray-700">
                                <input @change="isChannel = false" id="bordered-radio-2" type="radio" value="false"
                                    name="is_channel"
                                    class="hidden w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                <label for="bordered-radio-2"
                                    :class="{ 'text-gray-100': !isChannel, 'text-gray-900': isChannel }"
                                    class="w-full py-2 text-sm font-medium dark:text-gray-300">General</label>
                            </div>

                            <div x-show="isChannel">
                                <label for="application_id"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Application
                                    ID</label>
                                <input type="text" id="application_id" name="application_id"
                                    value="<?php echo e(old('application_id')); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Application ID">
                                <?php $__errorArgs = ['application_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php if (isset($component)) { $__componentOriginal58ef761b4a8d895ed279bb45cfc348ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'notify::components.notify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notify::notify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea)): ?>
<?php $attributes = $__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea; ?>
<?php unset($__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58ef761b4a8d895ed279bb45cfc348ea)): ?>
<?php $component = $__componentOriginal58ef761b4a8d895ed279bb45cfc348ea; ?>
<?php unset($__componentOriginal58ef761b4a8d895ed279bb45cfc348ea); ?>
<?php endif; ?>
                                    <div class="text-rose-500 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div x-show="!isChannel">
                                <label for="number_of_docs"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Number of
                                    Documents</label>
                                <input type="number" id="number_of_docs" name="number_of_docs"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Number of Documents">
                                <?php $__errorArgs = ['number_of_docs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-rose-500 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="">
                                <label for="client"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Client Name</label>
                                <select id="client" name="user_id" class="tail-select !w-full">
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>" <?php if(old('user_id') == $client->id): echo 'selected'; endif; ?>><?php echo e($client->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-rose-500 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="">
                                <label for="police_station"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Police
                                    Station</label>
                                <select id="police_station" name="police_station" class="tail-select !w-full">
                                    <?php $__currentLoopData = getPoliceStations(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($station->name); ?>"<?php if(old('police_station') == $station->name): echo 'selected'; endif; ?>>
                                            <?php echo e($station->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['police_station'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-rose-500 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div>
                                <label for="time"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Time</label>
                                <input type="time" x-init="function() {
                                    let d = (new Date().getHours()).toString()
                                    let m = (new Date().getMinutes()).toString()
                                    d = d.length < 2 ? '0' + d : d
                                    m = m.length < 2 ? '0' + m : m
                                
                                    $el.value = d + ':' + m
                                
                                }" id="time" name="time"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Time">
                            </div>

                        </div>
                        <div class="col-span-2">
                            <div>
                                <label for="date"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date</label>
                                <div class="relative flex items-center">
                                    <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                            <path
                                                d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                                        </svg>
                                    </div>
                                    <input id="date" name="date" type="date"
                                        value="<?php echo e(request()->date ?? today('Asia/Dhaka')->format('Y-m-d')); ?>"
                                        class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        placeholder="Select date">
                                </div>
                            </div>
                        </div>



                    </div>
                    <!-- Modal footer -->
                    <div
                        class="flex justify-end gap-4 items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                        <?php if (isset($component)) { $__componentOriginalc86eb860baf829b19e2abe8751f7efa9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9 = $attributes; } ?>
<?php $component = App\View\Components\BtnDanger::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnDanger::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-modal-hide' => 'create-modal','type' => 'button']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $attributes = $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $component = $__componentOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $attributes; } ?>
<?php $component = App\View\Components\BtnPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnPrimary::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $attributes = $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $component = $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit modal -->
    <div id="edit-modal" tabindex="-1" aria-hidden="true"
        class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        New Entry
                    </h3>
                    <button type="button"
                        class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        data-modal-hide="edit-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                            viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <form id="hx-edit-form" action="<?php echo e(route('entry.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="p-4 md:p-5 space-y-4">

                        <div class="grid gap-6 mb-6 md:grid-cols-2" x-data="{ isChannel: true }">

                            <div role="button" :class="{ 'bg-purple-600': isChannel }"
                                class="flex max-w-max items-center px-4 border border-gray-200 rounded-lg dark:border-gray-700">
                                <input @change="isChannel= true" id="bordered-radio-1" type="radio" value="true"
                                    name="is_channel" checked
                                    class="hidden w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                <label for="bordered-radio-1"
                                    :class="{ 'text-gray-100': isChannel, 'text-gray-900': !isChannel }"
                                    class="w-full py-2 text-sm font-medium dark:text-gray-300">Channel</label>
                            </div>
                            <div role="button" :class="{ 'bg-purple-600': !isChannel }"
                                class="flex justify-self-end max-w-max items-center px-4 border border-gray-200 rounded-lg dark:border-gray-700">
                                <input @change="isChannel = false" id="bordered-radio-2" type="radio" value="false"
                                    name="is_channel"
                                    class="hidden w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                <label for="bordered-radio-2"
                                    :class="{ 'text-gray-100': !isChannel, 'text-gray-900': isChannel }"
                                    class="w-full py-2 text-sm font-medium dark:text-gray-300">General</label>
                            </div>

                            <div x-show="isChannel">
                                <label for="application_id"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Application
                                    ID</label>
                                <input type="text" id="application_id" name="application_id"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Application ID">
                            </div>
                            <div x-show="!isChannel">
                                <label for="number_of_docs"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Number of
                                    Documents</label>
                                <input type="number" id="number_of_docs" name="number_of_docs"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Number of Documents">
                            </div>

                            <div class="">
                                <label for="client"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Client
                                    Name</label>
                                <select id="client" name="user_id" class="tail-select w-full">
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                            <div>
                                <label for="police_station"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Police
                                    Station</label>
                                <input type="text" id="police_station" name="police_station"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Police Station">
                            </div>
                            <div>
                                <label for="time"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Time</label>
                                <input type="time" x-init="function() {
                                    let d = (new Date().getHours()).toString()
                                    let m = (new Date().getMinutes()).toString()
                                    d = d.length < 2 ? '0' + d : d
                                    m = m.length < 2 ? '0' + m : m
                                
                                    $el.value = d + ':' + m
                                
                                }" id="time" name="time"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Time">
                            </div>

                            <div class="col-span-2">
                                <div>
                                    <label for="date"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date</label>
                                    <div class="relative flex items-center">
                                        <div
                                            class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                                            <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                                xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                                viewBox="0 0 20 20">
                                                <path
                                                    d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                                            </svg>
                                        </div>
                                        <input id="date" name="date" type="date"
                                            value="<?php echo e(today('Asia/Dhaka')->format('Y-m-d')); ?>"
                                            class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="Select date">
                                    </div>
                                </div>
                            </div>

                        </div>


                    </div>
                    <!-- Modal footer -->
                    <div
                        class="flex justify-end gap-4 items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                        <?php if (isset($component)) { $__componentOriginalc86eb860baf829b19e2abe8751f7efa9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9 = $attributes; } ?>
<?php $component = App\View\Components\BtnDanger::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnDanger::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-modal-hide' => 'edit-modal','type' => 'button']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $attributes = $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $component = $__componentOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $attributes; } ?>
<?php $component = App\View\Components\BtnPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnPrimary::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $attributes = $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $component = $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="w-full overflow-hidden rounded-lg shadow-xs">
        <div class="w-full overflow-x-auto">
            <table class="w-full whitespace-no-wrap">
                <thead>
                    <tr
                        class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                        <th class="px-4 py-3 text-center">No.</th>
                        <th class="px-4 py-3">Client Name</th>
                        <th class="px-4 py-3">Entry Date</th>
                        <th class="px-4 py-3">Document Type</th>
                        <th class="px-4 py-3">Application ID</th>
                        <th class="px-4 py-3">Police Station</th>
                        <th class="px-4 py-3">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-gray-700 dark:text-gray-400">
                            <td class="align-middle text-center"><?php echo e(++$key); ?></td>
                            <td class="px-4 py-3">
                                <div class="flex items-center text-sm">
                                    <!-- Avatar with inset shadow -->
                                    <div class="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                                        <img class="object-cover w-full h-full rounded-full"
                                            src="<?php echo e($entry->user->avatar); ?>" alt="" loading="lazy" />
                                        <div class="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
                                    </div>
                                    <div>
                                        <p class="font-semibold"><?php echo e($entry->user->name); ?></p>
                                        <p class="text-xs text-gray-600 dark:text-gray-400">
                                            <?php echo e($entry->user->username); ?>

                                        </p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 text-sm py-3">
                                <div><?php echo e(\Carbon\Carbon::parse($entry->date)->format('d F, Y')); ?></div>
                            </td>
                            <td class="px-4 py-3 text-sm capitalize">
                                <div><?php echo e($entry->doc_type); ?></div>
                            </td>
                            <td class="px-4 py-3 text-sm capitalize">
                                <?php echo e($entry->application_id ?? 'Not Applicable'); ?>

                            </td>
                            <td class="px-4 py-3 text-sm capitalize">
                                <?php echo e($entry->police_station); ?>

                            </td>
                            <td class="px-4 py-3">
                                <div class="flex items-center space-x-4 text-sm">
                                    <button data-modal-target="edit-modal" data-modal-toggle="edit-modal"
                                        hx-get="<?php echo e(route('entry.edit', $entry)); ?>" hx-transition
                                        hx-target="#hx-edit-form"
                                        class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                        aria-label="Edit">
                                        <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20">
                                            <path
                                                d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z">
                                            </path>
                                        </svg>
                                    </button>
                                    <form action="<?php echo e(route('entry.destroy', $entry)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button
                                            class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                            aria-label="Delete">
                                            <svg class="w-5 h-5" aria-hidden="true" fill="currentColor"
                                                viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if (isset($component)) { $__componentOriginal1411ee955ee315282daf3f10c0873057 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1411ee955ee315282daf3f10c0873057 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tr.no-records','data' => ['colspan' => '6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tr.no-records'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => '6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1411ee955ee315282daf3f10c0873057)): ?>
<?php $attributes = $__attributesOriginal1411ee955ee315282daf3f10c0873057; ?>
<?php unset($__attributesOriginal1411ee955ee315282daf3f10c0873057); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1411ee955ee315282daf3f10c0873057)): ?>
<?php $component = $__componentOriginal1411ee955ee315282daf3f10c0873057; ?>
<?php unset($__componentOriginal1411ee955ee315282daf3f10c0873057); ?>
<?php endif; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>





        
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/datepicker.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emon/projects/passport-entry/resources/views/dashboard/entry/index.blade.php ENDPATH**/ ?>