<form id="hx-edit-form" action="<?php echo e(route('entry.update', $entry)); ?>" method="post" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="p-4 md:p-5 space-y-4">

        <div class="grid gap-6 mb-6 md:grid-cols-2" x-data="{ isChannel: '<?php echo e($entry->doc_type == 'channel'); ?>' }">

            <div role="button" :class="{ 'bg-purple-600': isChannel }"
                class="flex max-w-max items-center px-4 border border-gray-200 rounded-lg dark:border-gray-700">
                <input @change="isChannel= true" id="bordered-radio-1" type="radio" value="true" name="is_channel"
                    <?php if($entry->doc_type == 'channel'): echo 'checked'; endif; ?>
                    class="hidden w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                <label for="bordered-radio-1" :class="{ 'text-gray-100': isChannel, 'text-gray-900': !isChannel }"
                    class="w-full py-2 text-sm font-medium dark:text-gray-300">Channel</label>
            </div>
            <div role="button" :class="{ 'bg-purple-600': !isChannel }"
                class="flex justify-self-end max-w-max items-center px-4 border border-gray-200 rounded-lg dark:border-gray-700">
                <input @change="isChannel = false" id="bordered-radio-2" type="radio" value="false" name="is_channel"
                    <?php if($entry->doc_type == 'general'): echo 'checked'; endif; ?>
                    class="hidden w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                <label for="bordered-radio-2" :class="{ 'text-gray-100': !isChannel, 'text-gray-900': isChannel }"
                    class="w-full py-2 text-sm font-medium dark:text-gray-300">General</label>
            </div>

            <div x-show="isChannel">
                <label for="application_id"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Application
                    ID</label>
                <input type="text" id="application_id" name="application_id" value="<?php echo e($entry->application_id); ?>"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Application ID">
            </div>
            <div x-show="!isChannel">
                <label for="number_of_docs" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Number
                    of
                    Documents</label>
                <input type="number" id="number_of_docs" name="number_of_docs"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Number of Documents">
            </div>

            <div class="">
                <label for="client" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Client
                    Name</label>
                <select id="client" name="user_id" class="tail-select w-full">
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($client->id); ?>" <?php if($client->id == $entry->user_id): echo 'selected'; endif; ?>><?php echo e($client->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div class="">
                <label for="police_station"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Police Station</label>
                <select id="police_station" name="police_station" class="tail-select !w-full">
                    <?php $__currentLoopData = getPoliceStations(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($station->name); ?>" <?php if($station->name == $entry->police_station): echo 'selected'; endif; ?>><?php echo e($station->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div>
                <label for="time" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Time</label>
                <input type="time" x-init="function() {
                    let d = (new Date().getHours()).toString()
                    let m = (new Date().getMinutes()).toString()
                    d = d.length < 2 ? '0' + d : d
                    m = m.length < 2 ? '0' + m : m
                
                    $el.value = d + ':' + m
                
                }" id="time" name="time" value="<?php echo e($entry->time); ?>"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Time">
            </div>

            <div class="col-span-2">
                <div>
                    <label for="date"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date</label>
                    <div class="relative flex items-center">
                        <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                            <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                <path
                                    d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                            </svg>
                        </div>
                        <input id="date" name="date" type="date" value="<?php echo e($entry->date); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            placeholder="Select date">
                    </div>
                </div>
            </div>

        </div>


    </div>
    <!-- Modal footer -->
    <div class="flex justify-end gap-4 items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
        <?php if (isset($component)) { $__componentOriginalc86eb860baf829b19e2abe8751f7efa9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9 = $attributes; } ?>
<?php $component = App\View\Components\BtnDanger::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnDanger::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-modal-hide' => 'create-modal','type' => 'button']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $attributes = $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $component = $__componentOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $attributes; } ?>
<?php $component = App\View\Components\BtnPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnPrimary::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $attributes = $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $component = $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
    </div>
</form>

<script src="https://cdn.jsdelivr.net/npm/tail.select.js@1.0.0/js/tail.select.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        tail.select('.tail-select')

            document.addEventListener('htmx:afterSettle', () => {
                tail.select('.tail-select').reload()
            });
        console.log(tail);
    });

</script>
<?php /**PATH /home/emon/projects/passport-entry/resources/views/dashboard/entry/partials/edit.blade.php ENDPATH**/ ?>