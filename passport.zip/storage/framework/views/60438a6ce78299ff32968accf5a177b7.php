<?php $__env->startSection('content'); ?>
    <table class="w-full">
        <thead>
            <tr
                class="text-xs font-bold tracking-wide text-left text-gray-700 uppercase border-b dark:border-gray-800 bg-gray-100 dark:text-gray-400 dark:bg-gray-800">
                <th rowspan="2" colspan="2"
                    class=" text-center px-2 md:px-10 border border-slate-600 py-2 md:py-4 text-sm md:text-xl capitalize max-w-max">
                    Monthly Short Report <span class="hidden lg:inline-block">-</span>
                    <div class="text-purple-600 lg:inline-block"><?php echo e(now()->format('F') . ', ' . now()->format('Y')); ?>

                    </div>
                </th>
            </tr>
        </thead>
        <tbody class="border-t">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                    class="border-t font-medium md:font-semibold text-wrap text-left text-gray-700 border dark:border-gray-800 bg-gray-100 dark:text-gray-400 dark:bg-gray-800">
                    <td class="px-1 md:px-4 lg:px-10 border border-slate-600 py-1 text-xs md:text-lg capitalize">
                        <?php echo e($key); ?></td>
                    <td class="px-1 md:px-4 lg:px-10 text-center border border-slate-600 py-1 text-xs md:text-lg">
                        <?php echo e($value); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emon/projects/passport-entry/resources/views/dashboard/index.blade.php ENDPATH**/ ?>