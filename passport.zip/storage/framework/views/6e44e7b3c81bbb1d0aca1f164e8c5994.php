 <!-- Modal body -->
 <form id="hx-edit-form" action="<?php echo e(route('client.update', $client)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="p-4 md:p-5 space-y-4">

        <div class="grid gap-6 mb-6 md:grid-cols-2" x-data="{ name: '<?php echo e($client->name); ?>', random() { return Math.floor(Math.random() * 1000) + 100 } }">
            <div>
                <label for="name"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Name</label>
                <input x-model="name" type="text" id="name" name="name"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="John" required>
            </div>

            <div class="">
                <label for="police_station"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Police Station</label>
                <select id="police_station" name="police_station" class="tail-select !w-full">
                    <?php $__currentLoopData = getPoliceStations(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($station->name); ?>" <?php if($station->name == $client->police_station): echo 'selected'; endif; ?>><?php echo e($station->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div>
                <label for="username"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Username</label>
                <input x-ref="username" value="<?php echo e($client->username); ?>" type="text" id="username" name="username"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="username" required>
            </div>
            <div>
                <label for="password"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Password</label>
                <input type="password" id="password" name="password"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Password">
            </div>

        </div>


    </div>
    <!-- Modal footer -->
    <div
        class="flex justify-end gap-4 items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
        <?php if (isset($component)) { $__componentOriginalc86eb860baf829b19e2abe8751f7efa9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9 = $attributes; } ?>
<?php $component = App\View\Components\BtnDanger::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnDanger::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-modal-hide' => 'edit-modal','type' => 'button']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $attributes = $__attributesOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__attributesOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9)): ?>
<?php $component = $__componentOriginalc86eb860baf829b19e2abe8751f7efa9; ?>
<?php unset($__componentOriginalc86eb860baf829b19e2abe8751f7efa9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90 = $attributes; } ?>
<?php $component = App\View\Components\BtnPrimary::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnPrimary::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-modal-hide' => 'edit-modal','type' => 'submit']); ?>Update <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $attributes = $__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__attributesOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90)): ?>
<?php $component = $__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90; ?>
<?php unset($__componentOriginale9f8ed34e636fb61e0f9da0d3bcdbd90); ?>
<?php endif; ?>
    </div>
</form><?php /**PATH /home/emon/projects/passport-entry/resources/views/dashboard/client/partials/edit.blade.php ENDPATH**/ ?>