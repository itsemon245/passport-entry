<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Report PDF</title>
</head>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        border: 1px solid black;
        text-align: center;
        vertical-align: middle;
    }

    td,
    th {
        padding: 2px;
    }

    .first-child,
    .border-none {
        border: none;
    }

    .first-child {
        border-top: 1px solid black;
    }

    .not-center {
        text-align: start;
    }

    .not-padding {
        padding: 0;
    }
</style>

<body>
    <h3 style="text-align: center;font-size:20px; font-weight:bold;margin-bottom:8px;">Report List
        <div style="color:#7e3af2;">(
            <?php if(request()->date_from == request()->date_to): ?>
                <?php echo e(\Carbon\Carbon::parse(request()->date_from)->format('d F, Y')); ?>

            <?php else: ?>
                <?php echo e(\Carbon\Carbon::parse(request()->date_from)->format('d F, Y')); ?> -
                <?php echo e(\Carbon\Carbon::parse(request()->date_to)->format('d F, Y')); ?>

            <?php endif; ?>
            )
        </div>
    </h3>
    <table>
        <thead>
            <tr>
                <th rowspan="2">No.</th>
                <th rowspan="2">Client Name</th>
                <th colspan="2">Survey</th>
                <th rowspan="2">Application ID</th>
                <th rowspan="2">Police Station</th>
            </tr>
            <tr>
                <th>Channel</th>
                <th>General</th>
            </tr>
        </thead>
        <tbody class="">
            <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td class="not-center">
                        <p class="font-semibold"><?php echo e($client->name); ?></p>
                    </td>
                    <td>
                        <?php echo e($client->channel_count); ?>

                    </td>
                    <td>
                        <?php echo e($client->general_count); ?>

                    </td>
                    <td class="no-padding">
                        <?php $__currentLoopData = $client->entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table style="width:100%;border-collapse:collapse;"
                                class="<?php echo e($client->entries->count() == 1 || $i == 0 ? '' : 'first-child'); ?> w-full">
                                <tr class="border-none">
                                    <td class="border-none"><?php echo e($entry->application_id); ?></td>
                                </tr>
                            </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="no-padding">
                        <?php $__currentLoopData = $client->entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table style="width:100%;border-collapse:collapse;"
                                class="<?php echo e($client->entries->count() == 1 || $i == 0 ? '' : 'first-child'); ?> w-full">
                                <tr class="border-none">
                                    <td class="border-none"><?php echo e($entry->police_station); ?></td>
                                </tr>
                            </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginal1411ee955ee315282daf3f10c0873057 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1411ee955ee315282daf3f10c0873057 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tr.no-records','data' => ['colspan' => '7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tr.no-records'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => '7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1411ee955ee315282daf3f10c0873057)): ?>
<?php $attributes = $__attributesOriginal1411ee955ee315282daf3f10c0873057; ?>
<?php unset($__attributesOriginal1411ee955ee315282daf3f10c0873057); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1411ee955ee315282daf3f10c0873057)): ?>
<?php $component = $__componentOriginal1411ee955ee315282daf3f10c0873057; ?>
<?php unset($__componentOriginal1411ee955ee315282daf3f10c0873057); ?>
<?php endif; ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH /home/emon/projects/passport-entry/resources/views/dashboard/report/pdf.blade.php ENDPATH**/ ?>